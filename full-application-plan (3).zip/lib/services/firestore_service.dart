import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/equipment_model.dart';
import '../models/worker_model.dart';
import '../models/land_model.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // إضافة معدة جديدة
  Future<void> addEquipment(EquipmentModel equipment) async {
    try {
      await _firestore.collection('equipment').doc(equipment.id).set(
            equipment.toJson(),
          );
    } catch (e) {
      print('خطأ في إضافة المعدة: $e');
    }
  }

  // الحصول على جميع المعدات
  Future<List<EquipmentModel>> getEquipment() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection('equipment').get();
      return snapshot.docs
          .map((doc) => EquipmentModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في جلب المعدات: $e');
      return [];
    }
  }

  // البحث عن معدات حسب الولاية
  Future<List<EquipmentModel>> searchEquipmentByWilaya(String wilaya) async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('equipment')
          .where('wilaya', isEqualTo: wilaya)
          .get();
      return snapshot.docs
          .map((doc) => EquipmentModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في البحث: $e');
      return [];
    }
  }

  // إضافة عامل جديد
  Future<void> addWorker(WorkerModel worker) async {
    try {
      await _firestore.collection('workers').doc(worker.id).set(
            worker.toJson(),
          );
    } catch (e) {
      print('خطأ في إضافة العامل: $e');
    }
  }

  // الحصول على جميع العمال
  Future<List<WorkerModel>> getWorkers() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection('workers').get();
      return snapshot.docs
          .map((doc) => WorkerModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في جلب العمال: $e');
      return [];
    }
  }

  // إضافة أرض جديدة
  Future<void> addLand(LandModel land) async {
    try {
      await _firestore.collection('lands').doc(land.id).set(
            land.toJson(),
          );
    } catch (e) {
      print('خطأ في إضافة الأرض: $e');
    }
  }

  // الحصول على جميع الأراضي
  Future<List<LandModel>> getLands() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection('lands').get();
      return snapshot.docs
          .map((doc) => LandModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في جلب الأراضي: $e');
      return [];
    }
  }
}
