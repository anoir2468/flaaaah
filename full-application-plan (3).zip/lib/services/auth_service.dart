import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // تسجيل مستخدم جديد
  Future<UserModel?> registerUser({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String wilaya,
    required String commune,
    required String userType,
  }) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = result.user;
      if (user != null) {
        UserModel newUser = UserModel(
          id: user.uid,
          name: name,
          email: email,
          phone: phone,
          wilaya: wilaya,
          commune: commune,
          userType: userType,
          createdAt: DateTime.now(),
        );
        return newUser;
      }
    } catch (e) {
      print('خطأ في التسجيل: $e');
    }
    return null;
  }

  // تسجيل الدخول
  Future<UserModel?> loginUser({
    required String email,
    required String password,
  }) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = result.user;
      if (user != null) {
        return UserModel(
          id: user.uid,
          name: user.displayName ?? 'مستخدم',
          email: user.email ?? '',
          phone: '',
          wilaya: '',
          commune: '',
          userType: 'farmer',
          createdAt: DateTime.now(),
        );
      }
    } catch (e) {
      print('خطأ في تسجيل الدخول: $e');
    }
    return null;
  }

  // تسجيل الخروج
  Future<void> logoutUser() async {
    await _auth.signOut();
  }

  // الحصول على المستخدم الحالي
  User? getCurrentUser() {
    return _auth.currentUser;
  }
}
