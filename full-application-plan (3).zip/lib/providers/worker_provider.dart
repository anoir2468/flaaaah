import 'package:flutter/material.dart';
import '../models/worker_model.dart';
import '../services/firestore_service.dart';

class WorkerProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  List<WorkerModel> _workersList = [];
  bool _isLoading = false;

  List<WorkerModel> get workersList => _workersList;
  bool get isLoading => _isLoading;

  Future<void> fetchWorkers() async {
    _isLoading = true;
    notifyListeners();

    try {
      _workersList = await _firestoreService.getWorkers();
    } catch (e) {
      print('خطأ في جلب العمال: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> addWorker(WorkerModel worker) async {
    try {
      await _firestoreService.addWorker(worker);
      _workersList.add(worker);
      notifyListeners();
    } catch (e) {
      print('خطأ في إضافة العامل: $e');
    }
  }
}
