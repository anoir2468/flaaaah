import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  UserModel? _currentUser;
  bool _isLoading = false;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _currentUser != null;

  Future<bool> register({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String wilaya,
    required String commune,
    required String userType,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      UserModel? user = await _authService.registerUser(
        email: email,
        password: password,
        name: name,
        phone: phone,
        wilaya: wilaya,
        commune: commune,
        userType: userType,
      );

      if (user != null) {
        _currentUser = user;
        _isLoading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      print('خطأ في التسجيل: $e');
    }

    _isLoading = false;
    notifyListeners();
    return false;
  }

  Future<bool> login({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      UserModel? user = await _authService.loginUser(
        email: email,
        password: password,
      );

      if (user != null) {
        _currentUser = user;
        _isLoading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      print('خطأ في تسجيل الدخول: $e');
    }

    _isLoading = false;
    notifyListeners();
    return false;
  }

  Future<void> logout() async {
    await _authService.logoutUser();
    _currentUser = null;
    notifyListeners();
  }
}
