import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/colors.dart';

class ImagePickerWidget extends StatefulWidget {
  final Function(List<String>) onImagesSelected;

  const ImagePickerWidget({
    Key? key,
    required this.onImagesSelected,
  }) : super(key: key);

  @override
  State<ImagePickerWidget> createState() => _ImagePickerWidgetState();
}

class _ImagePickerWidgetState extends State<ImagePickerWidget> {
  List<String> _selectedImages = [];

  void _pickImages() {
    // [v0] In a real app, use image_picker package here
    setState(() {
      _selectedImages.add('picked_image_${_selectedImages.length + 1}.jpg');
    });
    widget.onImagesSelected(_selectedImages);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'الصور',
          style: GoogleFonts.cairo(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        if (_selectedImages.isNotEmpty)
          SizedBox(
            height: 100,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _selectedImages.length,
              itemBuilder: (context, index) {
                return Container(
                  width: 100,
                  margin: const EdgeInsets.only(left: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: AppColors.lightGrey,
                  ),
                  child: const Icon(Icons.image, color: AppColors.grey),
                );
              },
            ),
          ),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: _pickImages, // call simulated pick images
          child: Container(
            height: 100,
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.primary, width: 2, style: BorderStyle.solid),
              borderRadius: BorderRadius.circular(12),
              color: AppColors.lightGrey,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.image, size: 48, color: AppColors.primary),
                const SizedBox(height: 8),
                Text(
                  'اضغط لإضافة صور',
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
