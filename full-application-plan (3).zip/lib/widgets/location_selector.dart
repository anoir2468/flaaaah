import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/colors.dart';

class LocationSelector extends StatefulWidget {
  final Function(String) onWilayaChanged;
  final Function(String) onCommuneChanged;

  const LocationSelector({
    Key? key,
    required this.onWilayaChanged,
    required this.onCommuneChanged,
  }) : super(key: key);

  @override
  State<LocationSelector> createState() => _LocationSelectorState();
}

class _LocationSelectorState extends State<LocationSelector> {
  String _selectedWilaya = '';
  String _selectedCommune = '';

  final Map<String, List<String>> _wilayas = {
    'سطيف': ['سطيف', 'عين الدفلى', 'بني عثمان'],
    'تيزي وزو': ['تيزي وزو', 'درعة', 'ناث إيراثن'],
    'البليدة': ['البليدة', 'الشريعة', 'سوق أهراس'],
    'الجزائر': ['الجزائر', 'بن عكنون', 'الشراقة'],
  };

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        DropdownButtonFormField<String>(
          value: _selectedWilaya.isEmpty ? null : _selectedWilaya,
          decoration: InputDecoration(
            hintText: 'اختر الولاية *',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            filled: true,
            fillColor: AppColors.white,
          ),
          items: _wilayas.keys
              .map((wilaya) => DropdownMenuItem(
                    value: wilaya,
                    child: Text(wilaya, style: GoogleFonts.cairo()),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _selectedWilaya = value ?? '';
              _selectedCommune = '';
            });
            widget.onWilayaChanged(value ?? '');
          },
        ),
        const SizedBox(height: 16),
        if (_selectedWilaya.isNotEmpty)
          DropdownButtonFormField<String>(
            value: _selectedCommune.isEmpty ? null : _selectedCommune,
            decoration: InputDecoration(
              hintText: 'اختر البلدية *',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              filled: true,
              fillColor: AppColors.white,
            ),
            items: (_wilayas[_selectedWilaya] ?? [])
                .map((commune) => DropdownMenuItem(
                      value: commune,
                      child: Text(commune, style: GoogleFonts.cairo()),
                    ))
                .toList(),
            onChanged: (value) {
              setState(() => _selectedCommune = value ?? '');
              widget.onCommuneChanged(value ?? '');
            },
          ),
      ],
    );
  }
}
