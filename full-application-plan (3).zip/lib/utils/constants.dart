class AppConstants {
  // رسائل
  static const String appName = 'منصة الفلاح';
  static const String appSubtitle = 'منصة زراعية متكاملة للفلاح الجزائري';
  
  // المسافات
  static const double paddingSmall = 8.0;
  static const double paddingMedium = 16.0;
  static const double paddingLarge = 24.0;
  
  // أحجام الخطوط
  static const double fontSizeSmall = 12.0;
  static const double fontSizeMedium = 14.0;
  static const double fontSizeLarge = 18.0;
  static const double fontSizeXLarge = 24.0;
  
  // أنواع المعدات
  static const List<String> equipmentTypes = [
    'جرار',
    'حصادة',
    'محراث',
    'بيوت بلاستيكية',
    'نظام ري',
    'رشاش',
    'أخرى',
  ];
  
  // تخصصات العمال
  static const List<String> workerSpecialties = [
    'حرث',
    'زراعة',
    'حصاد',
    'ري',
    'صيانة',
    'أخرى',
  ];
  
  // أنواع الأراضي
  static const List<String> landTypes = [
    'أرض صالحة للزراعة',
    'أرض مروية',
    'أرض بعلية',
    'أرض مع منشآت',
  ];
}
