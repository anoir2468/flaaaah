import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/worker_model.dart';
import '../../utils/colors.dart';
import 'add_worker_screen.dart';

class WorkersListScreen extends StatefulWidget {
  const WorkersListScreen({Key? key}) : super(key: key);

  @override
  State<WorkersListScreen> createState() => _WorkersListScreenState();
}

class _WorkersListScreenState extends State<WorkersListScreen> {
  final List<WorkerModel> _workersList = [
    WorkerModel(
      id: '1',
      name: 'محمد علي',
      phone: '0661234567',
      specialty: 'حرث',
      wilaya: 'سطيف',
      commune: 'سطيف',
      description: 'عامل متخصص في الحرث والزراعة',
      dailyRate: 3000,
      rating: 4.7,
      reviewsCount: 15,
      createdAt: DateTime.now(),
      skills: ['حرث', 'زراعة', 'ري'],
    ),
    WorkerModel(
      id: '2',
      name: 'فاطمة محمود',
      phone: '0671234567',
      specialty: 'حصاد',
      wilaya: 'تيزي وزو',
      commune: 'تيزي وزو',
      description: 'عاملة متخصصة في الحصاد',
      dailyRate: 2500,
      rating: 4.5,
      reviewsCount: 10,
      createdAt: DateTime.now(),
      skills: ['حصاد', 'فرز'],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'العمال',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddWorkerScreen(),
            ),
          );
        },
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _workersList.length,
        itemBuilder: (context, index) {
          final worker = _workersList[index];
          return _buildWorkerCard(worker);
        },
      ),
    );
  }

  Widget _buildWorkerCard(WorkerModel worker) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: AppColors.primary,
                  child: const Icon(Icons.person, color: AppColors.white, size: 40),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        worker.name,
                        style: GoogleFonts.cairo(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        worker.specialty,
                        style: GoogleFonts.cairo(
                          fontSize: 12,
                          color: AppColors.grey,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(Icons.star, color: Colors.amber, size: 16),
                          const SizedBox(width: 4),
                          Text(
                            '${worker.rating} (${worker.reviewsCount})',
                            style: GoogleFonts.cairo(fontSize: 12),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              worker.description,
              style: GoogleFonts.cairo(
                fontSize: 13,
                color: AppColors.grey,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${worker.dailyRate} دج/يوم',
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary,
                  ),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                  ),
                  child: Text(
                    'التواصل',
                    style: GoogleFonts.cairo(color: AppColors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
