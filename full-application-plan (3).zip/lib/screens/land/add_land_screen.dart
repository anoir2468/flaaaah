import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../utils/colors.dart';
import '../../utils/constants.dart';
import '../../widgets/location_selector.dart';
import '../../widgets/image_picker_widget.dart'; // added image picker import

class AddLandScreen extends StatefulWidget {
  const AddLandScreen({Key? key}) : super(key: key);

  @override
  State<AddLandScreen> createState() => _AddLandScreenState();
}

class _AddLandScreenState extends State<AddLandScreen> {
  final _nameController = TextEditingController();
  final _areaController = TextEditingController();
  final _priceController = TextEditingController();
  final _descriptionController = TextEditingController();
  
  String _selectedType = AppConstants.landTypes[0];
  String _selectedWilaya = '';
  String _selectedCommune = '';
  String _selectedSoilType = 'تربة سوداء';
  bool _hasWater = false;
  bool _isLoading = false;
  List<String> _selectedImages = []; // added variable to store selected images

  @override
  void dispose() {
    _nameController.dispose();
    _areaController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _addLand() {
    if (_nameController.text.isEmpty ||
        _areaController.text.isEmpty ||
        _priceController.text.isEmpty ||
        _selectedWilaya.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى ملء جميع الحقول المطلوبة')),
      );
      return;
    }

    setState(() => _isLoading = true);
    
    Future.delayed(const Duration(seconds: 2), () {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إضافة الأرض بنجاح')),
      );
      Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إضافة أرض',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'معلومات الأرض',
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                hintText: 'اسم الأرض *',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedType,
              decoration: InputDecoration(
                hintText: 'نوع الأرض *',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
              items: AppConstants.landTypes
                  .map((type) => DropdownMenuItem(
                        value: type,
                        child: Text(type, style: GoogleFonts.cairo()),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() => _selectedType = value ?? AppConstants.landTypes[0]);
              },
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _areaController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'المساحة (هكتار) *',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _priceController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'السعر (دج) *',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _descriptionController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'وصف الأرض',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
            ),
            const SizedBox(height: 24),
            ImagePickerWidget(
              onImagesSelected: (images) {
                setState(() => _selectedImages = images); // handle selected images
              },
            ),
            const SizedBox(height: 24),
            Text(
              'الموقع',
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            LocationSelector(
              onWilayaChanged: (wilaya) {
                setState(() => _selectedWilaya = wilaya);
              },
              onCommuneChanged: (commune) {
                setState(() => _selectedCommune = commune);
              },
            ),
            const SizedBox(height: 24),
            Text(
              'معلومات إضافية',
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedSoilType,
              decoration: InputDecoration(
                hintText: 'نوع التربة',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
              items: ['تربة سوداء', 'تربة حمراء', 'تربة رملية', 'تربة طينية']
                  .map((type) => DropdownMenuItem(
                        value: type,
                        child: Text(type, style: GoogleFonts.cairo()),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() => _selectedSoilType = value ?? 'تربة سوداء');
              },
            ),
            const SizedBox(height: 16),
            CheckboxListTile(
              title: Text('يوجد مصدر ماء', style: GoogleFonts.cairo()),
              value: _hasWater,
              onChanged: (value) {
                setState(() => _hasWater = value ?? false);
              },
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isLoading ? null : _addLand,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: _isLoading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(AppColors.white),
                        strokeWidth: 2,
                      ),
                    )
                  : Text(
                      'إضافة الأرض',
                      style: GoogleFonts.cairo(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.white,
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
