import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../utils/colors.dart';
import 'add_supplies_screen.dart';

class SuppliesListScreen extends StatefulWidget {
  const SuppliesListScreen({Key? key}) : super(key: key);

  @override
  State<SuppliesListScreen> createState() => _SuppliesListScreenState();
}

class _SuppliesListScreenState extends State<SuppliesListScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الأدوية والأسمدة',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddSuppliesScreen(),
            ),
          );
        },
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add),
      ),
      body: Center(
        child: Text(
          'لا توجد أدوية أو أسمدة حالياً',
          style: GoogleFonts.cairo(fontSize: 16),
        ),
      ),
    );
  }
}
