import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/equipment_model.dart';
import '../../utils/colors.dart';
import 'add_equipment_screen.dart';

class EquipmentListScreen extends StatefulWidget {
  const EquipmentListScreen({Key? key}) : super(key: key);

  @override
  State<EquipmentListScreen> createState() => _EquipmentListScreenState();
}

class _EquipmentListScreenState extends State<EquipmentListScreen> {
  final List<EquipmentModel> _equipmentList = [
    EquipmentModel(
      id: '1',
      name: 'جرار زراعي',
      description: 'جرار قوي وموثوق للحرث والزراعة',
      type: 'جرار',
      price: 50000,
      forRent: true,
      forSale: true,
      wilaya: 'سطيف',
      commune: 'سطيف',
      sellerId: 'seller1',
      sellerName: 'أحمد محمد',
      images: [],
      rating: 4.5,
      reviewsCount: 12,
      createdAt: DateTime.now(),
    ),
    EquipmentModel(
      id: '2',
      name: 'حصادة',
      description: 'حصادة حديثة وفعالة',
      type: 'حصادة',
      price: 75000,
      forRent: true,
      forSale: false,
      wilaya: 'تيزي وزو',
      commune: 'تيزي وزو',
      sellerId: 'seller2',
      sellerName: 'فاطمة علي',
      images: [],
      rating: 4.8,
      reviewsCount: 8,
      createdAt: DateTime.now(),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'المعدات الزراعية',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddEquipmentScreen(),
            ),
          );
        },
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _equipmentList.length,
        itemBuilder: (context, index) {
          final equipment = _equipmentList[index];
          return _buildEquipmentCard(equipment);
        },
      ),
    );
  }

  Widget _buildEquipmentCard(EquipmentModel equipment) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 200,
              decoration: BoxDecoration(
                color: AppColors.lightGrey,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.agriculture, size: 80, color: AppColors.grey),
            ),
            const SizedBox(height: 12),
            Text(
              equipment.name,
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              equipment.description,
              style: GoogleFonts.cairo(
                fontSize: 14,
                color: AppColors.grey,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${equipment.price} دج',
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary,
                  ),
                ),
                Row(
                  children: [
                    const Icon(Icons.star, color: Colors.amber, size: 20),
                    const SizedBox(width: 4),
                    Text(
                      '${equipment.rating}',
                      style: GoogleFonts.cairo(fontSize: 14),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                if (equipment.forRent)
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.secondary,
                      ),
                      child: Text(
                        'إيجار',
                        style: GoogleFonts.cairo(color: AppColors.white),
                      ),
                    ),
                  ),
                if (equipment.forRent && equipment.forSale)
                  const SizedBox(width: 8),
                if (equipment.forSale)
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                      ),
                      child: Text(
                        'شراء',
                        style: GoogleFonts.cairo(color: AppColors.white),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
