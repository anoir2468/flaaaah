class WorkerModel {
  final String id;
  final String name;
  final String phone;
  final String specialty;
  final String wilaya;
  final String commune;
  final String description;
  final double dailyRate;
  final String? profileImage;
  final double rating;
  final int reviewsCount;
  final bool available;
  final DateTime createdAt;
  final List<String> skills;

  WorkerModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.specialty,
    required this.wilaya,
    required this.commune,
    required this.description,
    required this.dailyRate,
    this.profileImage,
    this.rating = 0.0,
    this.reviewsCount = 0,
    this.available = true,
    required this.createdAt,
    required this.skills,
  });

  factory WorkerModel.fromJson(Map<String, dynamic> json) {
    return WorkerModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      phone: json['phone'] ?? '',
      specialty: json['specialty'] ?? '',
      wilaya: json['wilaya'] ?? '',
      commune: json['commune'] ?? '',
      description: json['description'] ?? '',
      dailyRate: (json['dailyRate'] ?? 0.0).toDouble(),
      profileImage: json['profileImage'],
      rating: (json['rating'] ?? 0.0).toDouble(),
      reviewsCount: json['reviewsCount'] ?? 0,
      available: json['available'] ?? true,
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toString()),
      skills: List<String>.from(json['skills'] ?? []),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'specialty': specialty,
      'wilaya': wilaya,
      'commune': commune,
      'description': description,
      'dailyRate': dailyRate,
      'profileImage': profileImage,
      'rating': rating,
      'reviewsCount': reviewsCount,
      'available': available,
      'createdAt': createdAt.toIso8601String(),
      'skills': skills,
    };
  }
}
