class EquipmentModel {
  final String id;
  final String name;
  final String description;
  final String type;
  final double price;
  final bool forRent;
  final bool forSale;
  final String wilaya;
  final String commune;
  final String sellerId;
  final String sellerName;
  final List<String> images;
  final double rating;
  final int reviewsCount;
  final DateTime createdAt;
  final bool available;

  EquipmentModel({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.price,
    required this.forRent,
    required this.forSale,
    required this.wilaya,
    required this.commune,
    required this.sellerId,
    required this.sellerName,
    required this.images,
    this.rating = 0.0,
    this.reviewsCount = 0,
    required this.createdAt,
    this.available = true,
  });

  factory EquipmentModel.fromJson(Map<String, dynamic> json) {
    return EquipmentModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      type: json['type'] ?? '',
      price: (json['price'] ?? 0.0).toDouble(),
      forRent: json['forRent'] ?? false,
      forSale: json['forSale'] ?? false,
      wilaya: json['wilaya'] ?? '',
      commune: json['commune'] ?? '',
      sellerId: json['sellerId'] ?? '',
      sellerName: json['sellerName'] ?? '',
      images: List<String>.from(json['images'] ?? []),
      rating: (json['rating'] ?? 0.0).toDouble(),
      reviewsCount: json['reviewsCount'] ?? 0,
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toString()),
      available: json['available'] ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'type': type,
      'price': price,
      'forRent': forRent,
      'forSale': forSale,
      'wilaya': wilaya,
      'commune': commune,
      'sellerId': sellerId,
      'sellerName': sellerName,
      'images': images,
      'rating': rating,
      'reviewsCount': reviewsCount,
      'createdAt': createdAt.toIso8601String(),
      'available': available,
    };
  }
}
