class UserModel {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String wilaya;
  final String commune;
  final String userType; // farmer, worker, seller
  final String? profileImage;
  final DateTime createdAt;
  final double rating;
  final int reviewsCount;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.wilaya,
    required this.commune,
    required this.userType,
    this.profileImage,
    required this.createdAt,
    this.rating = 0.0,
    this.reviewsCount = 0,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'] ?? '',
      wilaya: json['wilaya'] ?? '',
      commune: json['commune'] ?? '',
      userType: json['userType'] ?? 'farmer',
      profileImage: json['profileImage'],
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toString()),
      rating: (json['rating'] ?? 0.0).toDouble(),
      reviewsCount: json['reviewsCount'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'wilaya': wilaya,
      'commune': commune,
      'userType': userType,
      'profileImage': profileImage,
      'createdAt': createdAt.toIso8601String(),
      'rating': rating,
      'reviewsCount': reviewsCount,
    };
  }
}
