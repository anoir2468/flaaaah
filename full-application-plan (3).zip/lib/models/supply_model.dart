class SupplyModel {
  final String id;
  final String name;
  final String type; // سماد، مبيد، بذور
  final String description;
  final double price;
  final String unit; // كيس، لتر، كغ
  final int quantity;
  final String wilaya;
  final String commune;
  final String sellerId;
  final String sellerName;
  final List<String> images;
  final double rating;
  final int reviewsCount;
  final DateTime createdAt;
  final bool available;

  SupplyModel({
    required this.id,
    required this.name,
    required this.type,
    required this.description,
    required this.price,
    required this.unit,
    required this.quantity,
    required this.wilaya,
    required this.commune,
    required this.sellerId,
    required this.sellerName,
    required this.images,
    this.rating = 0.0,
    this.reviewsCount = 0,
    required this.createdAt,
    this.available = true,
  });

  factory SupplyModel.fromJson(Map<String, dynamic> json) {
    return SupplyModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      type: json['type'] ?? '',
      description: json['description'] ?? '',
      price: (json['price'] ?? 0.0).toDouble(),
      unit: json['unit'] ?? '',
      quantity: json['quantity'] ?? 0,
      wilaya: json['wilaya'] ?? '',
      commune: json['commune'] ?? '',
      sellerId: json['sellerId'] ?? '',
      sellerName: json['sellerName'] ?? '',
      images: List<String>.from(json['images'] ?? []),
      rating: (json['rating'] ?? 0.0).toDouble(),
      reviewsCount: json['reviewsCount'] ?? 0,
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toString()),
      available: json['available'] ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type,
      'description': description,
      'price': price,
      'unit': unit,
      'quantity': quantity,
      'wilaya': wilaya,
      'commune': commune,
      'sellerId': sellerId,
      'sellerName': sellerName,
      'images': images,
      'rating': rating,
      'reviewsCount': reviewsCount,
      'createdAt': createdAt.toIso8601String(),
      'available': available,
    };
  }
}
