import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, MapPin, Calendar, DollarSign, Tractor, Plus } from "lucide-react"
import Link from "next/link"

export default function EquipmentPage() {
  const equipment = [
    {
      id: 1,
      name: "جرار زراعي 75 حصان",
      category: "جرارات",
      price: "2,500,000",
      location: "الجزائر العاصمة",
      condition: "جديد",
      image: "/agricultural-tractor.jpg",
      seller: "محمد بن علي",
      date: "منذ يومين",
      forRent: false,
    },
    {
      id: 2,
      name: "محراث قلاب 3 أسلحة",
      category: "محاريث",
      price: "450,000",
      location: "وهران",
      condition: "مستعمل",
      image: "/agricultural-plow.jpg",
      seller: "أحمد الحسني",
      date: "منذ 3 أيام",
      forRent: false,
    },
    {
      id: 3,
      name: "بيت بلاستيكي 500 متر",
      category: "بيوت بلاستيكية",
      price: "15,000",
      location: "قسنطينة",
      condition: "جديد",
      image: "/greenhouse-plastic.jpg",
      seller: "فاطمة زهراء",
      date: "منذ أسبوع",
      forRent: true,
      rentPeriod: "شهري",
    },
    {
      id: 4,
      name: "آلة حصاد حبوب",
      category: "آلات حصاد",
      price: "3,800,000",
      location: "سطيف",
      condition: "جديد",
      image: "/combine-harvester-field.png",
      seller: "يوسف بلعيد",
      date: "منذ 5 أيام",
      forRent: false,
    },
    {
      id: 5,
      name: "نظام ري بالتنقيط",
      category: "أنظمة ري",
      price: "180,000",
      location: "بجاية",
      condition: "جديد",
      image: "/drip-irrigation.png",
      seller: "كريم مرزوق",
      date: "منذ يوم",
      forRent: false,
    },
    {
      id: 6,
      name: "رشاش مبيدات",
      category: "معدات رش",
      price: "85,000",
      location: "تلمسان",
      condition: "مستعمل",
      image: "/agricultural-sprayer.png",
      seller: "سعيد بن عمر",
      date: "منذ 4 أيام",
      forRent: false,
    },
  ]

  const categories = ["جميع الفئات", "جرارات", "محاريث", "بيوت بلاستيكية", "آلات حصاد", "أنظمة ري", "معدات رش"]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-[#2d7a3e] to-[#10b981] text-white py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-4">
              <Tractor className="h-10 w-10" />
              <h1 className="text-3xl sm:text-4xl font-bold">المعدات الزراعية</h1>
            </div>
            <p className="text-lg text-green-50 max-w-2xl text-pretty">
              اشتري أو استأجر المعدات الزراعية التي تحتاجها لمشروعك
            </p>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="bg-white border-b border-border sticky top-16 z-40 shadow-sm">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input placeholder="ابحث عن معدات..." className="pr-10 h-11" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="الفئة" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  <SelectItem value="new">جديد</SelectItem>
                  <SelectItem value="used">مستعمل</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-[#2d7a3e] hover:bg-[#1f5a2d] h-11">
                <Filter className="h-5 w-5 ml-2" />
                تصفية
              </Button>
            </div>
          </div>
        </section>

        {/* Equipment Grid */}
        <section className="py-8">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center mb-6">
              <p className="text-muted-foreground">
                عرض <span className="font-bold text-foreground">{equipment.length}</span> معدة
              </p>
              <Link href="/equipment/add">
                <Button size="lg" className="bg-[#2d7a3e] text-white hover:bg-[#1f5a2d]">
                  <Plus className="h-5 w-5 ml-2" />
                  أضف معدة للبيع
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {equipment.map((item) => (
                <Card
                  key={item.id}
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="relative">
                    <img src={item.image || "/placeholder.svg"} alt={item.name} className="w-full h-48 object-cover" />
                    <div className="absolute top-3 right-3 flex gap-2">
                      <Badge className="bg-white text-foreground">{item.condition}</Badge>
                      {item.forRent && <Badge className="bg-[#2d7a3e] text-white">للإيجار</Badge>}
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="mb-2">
                      <Badge variant="outline" className="text-xs">
                        {item.category}
                      </Badge>
                    </div>
                    <h3 className="text-lg font-bold text-foreground mb-2 line-clamp-1">{item.name}</h3>
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        <span>{item.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>{item.date}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <div>
                        <div className="flex items-center gap-1 text-2xl font-bold text-[#2d7a3e]">
                          <DollarSign className="h-5 w-5" />
                          <span>{item.price}</span>
                        </div>
                        {item.forRent && <span className="text-xs text-muted-foreground">{item.rentPeriod}</span>}
                      </div>
                      <Button size="sm" className="bg-[#2d7a3e] hover:bg-[#1f5a2d]">
                        التفاصيل
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center gap-2 mt-8">
              <Button variant="outline" disabled>
                السابق
              </Button>
              <Button variant="outline" className="bg-[#2d7a3e] text-white hover:bg-[#1f5a2d] hover:text-white">
                1
              </Button>
              <Button variant="outline">2</Button>
              <Button variant="outline">3</Button>
              <Button variant="outline">التالي</Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
