"use client"

import type React from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { LocationSelector } from "@/components/location-selector"
import { Plus, Upload, X, Eye } from "lucide-react"
import { useState } from "react"

export default function AddFacilityPage() {
  const [images, setImages] = useState<string[]>([])
  const [showPreview, setShowPreview] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    type: "",
    area: "",
    price: "",
    wilaya: "",
    commune: "",
    description: "",
    capacity: "",
    facilities: [] as string[],
    forRent: false,
    rentPrice: "",
    condition: "",
    yearBuilt: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Facility submission:", formData, images)
    alert("تم نشر المنشأة بنجاح!")
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const newImages = Array.from(files).map((file) => URL.createObjectURL(file))
      setImages([...images, ...newImages].slice(0, 8))
    }
  }

  const facilityTypes = [
    "بيت بلاستيكي",
    "مخزن",
    "حظيرة",
    "مزرعة دواجن",
    "مزرعة أبقار",
    "مزرعة أغنام",
    "مصنع تحويل",
    "أخرى",
  ]

  const availableFacilities = ["كهرباء", "ماء", "صرف صحي", "تهوية", "تبريد", "تدفئة", "نظام ري", "أمن وحراسة"]

  const toggleFacility = (facility: string) => {
    setFormData({
      ...formData,
      facilities: formData.facilities.includes(facility)
        ? formData.facilities.filter((f) => f !== facility)
        : [...formData.facilities, facility],
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 bg-muted/30 py-8">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">إضافة منشأة زراعية</h1>
              <p className="text-muted-foreground">املأ النموذج أدناه لإضافة منشأتك الزراعية للبيع أو الإيجار</p>
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowPreview(!showPreview)}
              className="bg-transparent"
            >
              <Eye className="h-4 w-4 ml-2" />
              {showPreview ? "إخفاء المعاينة" : "معاينة"}
            </Button>
          </div>

          {showPreview && (
            <Card className="p-6 mb-6 bg-blue-50 border-blue-200">
              <h3 className="text-lg font-bold mb-4 text-blue-900">معاينة المنشأة</h3>
              <div className="bg-white rounded-lg p-4 border border-border">
                {images.length > 0 && (
                  <img
                    src={images[0] || "/placeholder.svg"}
                    alt="معاينة"
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                )}
                <h4 className="text-xl font-bold text-foreground mb-2">{formData.title || "عنوان المنشأة"}</h4>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                  <span>{formData.type || "النوع"}</span>
                  <span>•</span>
                  <span>{formData.area ? `${formData.area} م²` : "المساحة"}</span>
                  <span>•</span>
                  <span>{formData.wilaya || "الولاية"}</span>
                </div>
                <p className="text-2xl font-bold text-[#2d7a3e] mb-2">
                  {formData.price ? `${Number(formData.price).toLocaleString()} دج` : "السعر"}
                </p>
                {formData.forRent && formData.rentPrice && (
                  <p className="text-sm text-muted-foreground">
                    الإيجار: {Number(formData.rentPrice).toLocaleString()} دج/شهر
                  </p>
                )}
              </div>
            </Card>
          )}

          <form onSubmit={handleSubmit}>
            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-6">معلومات المنشأة</h2>

              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">
                    عنوان الإعلان <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="title"
                    placeholder="مثال: بيت بلاستيكي مجهز بالكامل - 500 م²"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="type">
                      نوع المنشأة <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value) => setFormData({ ...formData, type: value })}
                      required
                    >
                      <SelectTrigger id="type">
                        <SelectValue placeholder="اختر النوع" />
                      </SelectTrigger>
                      <SelectContent>
                        {facilityTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="area">
                      المساحة (م²) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="area"
                      type="number"
                      placeholder="0"
                      value={formData.area}
                      onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="capacity">
                      السعة <span className="text-muted-foreground text-xs">(اختياري)</span>
                    </Label>
                    <Input
                      id="capacity"
                      placeholder="مثال: 100 رأس، 5000 دجاجة"
                      value={formData.capacity}
                      onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="condition">
                      الحالة <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.condition}
                      onValueChange={(value) => setFormData({ ...formData, condition: value })}
                      required
                    >
                      <SelectTrigger id="condition">
                        <SelectValue placeholder="اختر الحالة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">جديد</SelectItem>
                        <SelectItem value="excellent">ممتاز</SelectItem>
                        <SelectItem value="good">جيد</SelectItem>
                        <SelectItem value="fair">مقبول</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="yearBuilt">
                      سنة البناء <span className="text-muted-foreground text-xs">(اختياري)</span>
                    </Label>
                    <Input
                      id="yearBuilt"
                      type="number"
                      placeholder="2020"
                      value={formData.yearBuilt}
                      onChange={(e) => setFormData({ ...formData, yearBuilt: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">
                      السعر (دج) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="price"
                      type="number"
                      placeholder="0"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      required
                    />
                  </div>

                  <LocationSelector
                    wilayaValue={formData.wilaya}
                    communeValue={formData.commune}
                    onWilayaChange={(value) => setFormData({ ...formData, wilaya: value })}
                    onCommuneChange={(value) => setFormData({ ...formData, commune: value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>
                    المرافق المتوفرة <span className="text-muted-foreground text-xs">(اختياري)</span>
                  </Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {availableFacilities.map((facility) => (
                      <div key={facility} className="flex items-center gap-2">
                        <Checkbox
                          id={facility}
                          checked={formData.facilities.includes(facility)}
                          onCheckedChange={() => toggleFacility(facility)}
                        />
                        <Label htmlFor={facility} className="text-sm cursor-pointer">
                          {facility}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">
                    الوصف <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="اكتب وصفاً تفصيلياً للمنشأة، مميزاتها، التجهيزات، الموقع..."
                    rows={6}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-4 pt-4 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="forRent"
                      checked={formData.forRent}
                      onCheckedChange={(checked) => setFormData({ ...formData, forRent: checked as boolean })}
                    />
                    <Label htmlFor="forRent" className="cursor-pointer">
                      متاح للإيجار
                    </Label>
                  </div>

                  {formData.forRent && (
                    <div className="space-y-2 mr-6">
                      <Label htmlFor="rentPrice">سعر الإيجار (دج/شهر)</Label>
                      <Input
                        id="rentPrice"
                        type="number"
                        placeholder="0"
                        value={formData.rentPrice}
                        onChange={(e) => setFormData({ ...formData, rentPrice: e.target.value })}
                      />
                    </div>
                  )}
                </div>
              </div>
            </Card>

            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-2">
                الصور <span className="text-red-500">*</span>
              </h2>
              <p className="text-sm text-muted-foreground mb-6">
                أضف صوراً واضحة للمنشأة من الداخل والخارج. الصورة الأولى ستكون الصورة الرئيسية.
              </p>
              <div className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {images.map((image, index) => (
                    <div
                      key={index}
                      className="relative aspect-square rounded-lg border-2 border-border overflow-hidden"
                    >
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`صورة ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      {index === 0 && (
                        <div className="absolute top-2 right-2 bg-[#2d7a3e] text-white text-xs px-2 py-1 rounded">
                          رئيسية
                        </div>
                      )}
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 left-2 h-8 w-8"
                        onClick={() => setImages(images.filter((_, i) => i !== index))}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  {images.length < 8 && (
                    <label className="aspect-square rounded-lg border-2 border-dashed border-border hover:border-[#2d7a3e] hover:bg-muted/50 transition-colors flex flex-col items-center justify-center gap-2 cursor-pointer">
                      <Upload className="h-8 w-8 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">إضافة صورة</span>
                      <input type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} />
                    </label>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  يمكنك إضافة حتى 8 صور. الحد الأدنى صورة واحدة. ({images.length}/8)
                </p>
              </div>
            </Card>

            <div className="flex gap-4">
              <Button
                type="submit"
                className="flex-1 bg-[#2d7a3e] hover:bg-[#1f5a2d] h-11"
                disabled={images.length === 0}
              >
                <Plus className="h-5 w-5 ml-2" />
                نشر الإعلان
              </Button>
              <Button type="button" variant="outline" className="h-11 bg-transparent">
                إلغاء
              </Button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  )
}
