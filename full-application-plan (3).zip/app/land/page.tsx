import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Filter, MapPin, Maximize, DollarSign, Building2, Plus } from "lucide-react"
import Link from "next/link"

export default function LandPage() {
  const lands = [
    {
      id: 1,
      title: "أرض زراعية خصبة 5 هكتار",
      type: "أرض",
      area: "5 هكتار",
      location: "الجزائر العاصمة",
      price: "15,000,000",
      forSale: true,
      waterSource: "بئر",
      soilType: "طينية",
      image: "/land-1.jpg",
      features: ["كهرباء", "طريق معبد", "سور"],
    },
    {
      id: 2,
      title: "أرض للإيجار 3 هكتار",
      type: "أرض",
      area: "3 هكتار",
      location: "وهران",
      price: "50,000",
      forSale: false,
      rentPeriod: "سنوي",
      waterSource: "شبكة عامة",
      soilType: "رملية",
      image: "/land-2.jpg",
      features: ["كهرباء", "ماء"],
    },
    {
      id: 3,
      title: "مزرعة متكاملة 10 هكتار",
      type: "أرض",
      area: "10 هكتار",
      location: "قسنطينة",
      price: "35,000,000",
      forSale: true,
      waterSource: "نهر",
      soilType: "خصبة",
      image: "/land-3.jpg",
      features: ["كهرباء", "ماء", "منزل", "مخزن"],
    },
  ]

  const facilities = [
    {
      id: 1,
      title: "بيت بلاستيكي 500 متر مربع",
      type: "منشأة",
      area: "500 متر",
      location: "سطيف",
      price: "2,500,000",
      forSale: true,
      condition: "جديد",
      image: "/facility-1.jpg",
      features: ["نظام تهوية", "نظام ري", "تدفئة"],
    },
    {
      id: 2,
      title: "مخزن زراعي 200 متر",
      type: "منشأة",
      area: "200 متر",
      location: "بجاية",
      price: "1,800,000",
      forSale: true,
      condition: "مستعمل",
      image: "/facility-2.jpg",
      features: ["كهرباء", "تهوية", "أمن"],
    },
    {
      id: 3,
      title: "بيت بلاستيكي للإيجار",
      type: "منشأة",
      area: "300 متر",
      location: "تلمسان",
      price: "25,000",
      forSale: false,
      rentPeriod: "شهري",
      condition: "جديد",
      image: "/facility-3.jpg",
      features: ["نظام ري", "تهوية"],
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-amber-600 to-orange-600 text-white py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-4">
              <MapPin className="h-10 w-10" />
              <h1 className="text-3xl sm:text-4xl font-bold">الأراضي والمنشآت الزراعية</h1>
            </div>
            <p className="text-lg text-amber-50 max-w-2xl text-pretty">
              اشتري أو استأجر أراضي زراعية ومنشآت حديثة لمشروعك
            </p>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="bg-white border-b border-border sticky top-16 z-40 shadow-sm">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input placeholder="ابحث عن أراضي أو منشآت..." className="pr-10 h-11" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="الولاية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الولايات</SelectItem>
                  <SelectItem value="algiers">الجزائر العاصمة</SelectItem>
                  <SelectItem value="oran">وهران</SelectItem>
                  <SelectItem value="constantine">قسنطينة</SelectItem>
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="النوع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="sale">للبيع</SelectItem>
                  <SelectItem value="rent">للإيجار</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-amber-600 hover:bg-amber-700 h-11">
                <Filter className="h-5 w-5 ml-2" />
                تصفية
              </Button>
            </div>
          </div>
        </section>

        {/* Tabs for Land and Facilities */}
        <section className="py-8">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <Tabs defaultValue="land" className="w-full">
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
                <TabsTrigger value="land">الأراضي الزراعية</TabsTrigger>
                <TabsTrigger value="facilities">المنشآت</TabsTrigger>
              </TabsList>

              {/* Land Tab */}
              <TabsContent value="land">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-muted-foreground">
                    عرض <span className="font-bold text-foreground">{lands.length}</span> أرض
                  </p>
                  <Link href="/land/add">
                    <Button size="lg" className="bg-amber-600 text-white hover:bg-amber-700">
                      <Plus className="h-5 w-5 ml-2" />
                      أضف أرض
                    </Button>
                  </Link>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {lands.map((land) => (
                    <Card
                      key={land.id}
                      className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                    >
                      <div className="relative">
                        <img
                          src={land.image || "/placeholder.svg"}
                          alt={land.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute top-3 right-3">
                          <Badge className={land.forSale ? "bg-green-600" : "bg-blue-600"}>
                            {land.forSale ? "للبيع" : "للإيجار"}
                          </Badge>
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="text-lg font-bold text-foreground mb-3 line-clamp-1">{land.title}</h3>
                        <div className="space-y-2 mb-4">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Maximize className="h-4 w-4" />
                            <span>المساحة: {land.area}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <MapPin className="h-4 w-4" />
                            <span>{land.location}</span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            <span>مصدر الماء: {land.waterSource}</span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            <span>نوع التربة: {land.soilType}</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-4">
                          {land.features.map((feature, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-border">
                          <div>
                            <div className="flex items-center gap-1 text-2xl font-bold text-amber-600">
                              <DollarSign className="h-5 w-5" />
                              <span>{land.price}</span>
                            </div>
                            {!land.forSale && <span className="text-xs text-muted-foreground">{land.rentPeriod}</span>}
                          </div>
                          <Button size="sm" className="bg-amber-600 hover:bg-amber-700">
                            التفاصيل
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Facilities Tab */}
              <TabsContent value="facilities">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-muted-foreground">
                    عرض <span className="font-bold text-foreground">{facilities.length}</span> منشأة
                  </p>
                  <Link href="/facilities/add">
                    <Button size="lg" className="bg-amber-600 text-white hover:bg-amber-700">
                      <Plus className="h-5 w-5 ml-2" />
                      أضف منشأة
                    </Button>
                  </Link>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {facilities.map((facility) => (
                    <Card
                      key={facility.id}
                      className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                    >
                      <div className="relative">
                        <img
                          src={facility.image || "/placeholder.svg"}
                          alt={facility.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute top-3 right-3 flex gap-2">
                          <Badge className="bg-white text-foreground">{facility.condition}</Badge>
                          <Badge className={facility.forSale ? "bg-green-600" : "bg-blue-600"}>
                            {facility.forSale ? "للبيع" : "للإيجار"}
                          </Badge>
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="text-lg font-bold text-foreground mb-3 line-clamp-1">{facility.title}</h3>
                        <div className="space-y-2 mb-4">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Building2 className="h-4 w-4" />
                            <span>المساحة: {facility.area}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <MapPin className="h-4 w-4" />
                            <span>{facility.location}</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-4">
                          {facility.features.map((feature, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-border">
                          <div>
                            <div className="flex items-center gap-1 text-2xl font-bold text-amber-600">
                              <DollarSign className="h-5 w-5" />
                              <span>{facility.price}</span>
                            </div>
                            {!facility.forSale && (
                              <span className="text-xs text-muted-foreground">{facility.rentPeriod}</span>
                            )}
                          </div>
                          <Button size="sm" className="bg-amber-600 hover:bg-amber-700">
                            التفاصيل
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
