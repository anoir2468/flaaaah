import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Filter, Leaf, ShoppingCart, Star, Package, Plus } from "lucide-react"
import Link from "next/link"

export default function SuppliesPage() {
  const fertilizers = [
    {
      id: 1,
      name: "سماد NPK متوازن",
      category: "أسمدة كيميائية",
      type: "NPK 20-20-20",
      size: "25 كغ",
      price: "3,500",
      rating: 4.7,
      reviews: 45,
      inStock: true,
      image: "/fertilizer-1.jpg",
      brand: "أجريكو",
    },
    {
      id: 2,
      name: "سماد عضوي طبيعي",
      category: "أسمدة عضوية",
      type: "كومبوست",
      size: "50 كغ",
      price: "2,800",
      rating: 4.9,
      reviews: 67,
      inStock: true,
      image: "/fertilizer-2.jpg",
      brand: "بيو فارم",
    },
    {
      id: 3,
      name: "سماد يوريا",
      category: "أسمدة نيتروجينية",
      type: "يوريا 46%",
      size: "50 كغ",
      price: "4,200",
      rating: 4.6,
      reviews: 38,
      inStock: true,
      image: "/fertilizer-3.jpg",
      brand: "فيرتي بلس",
    },
  ]

  const pesticides = [
    {
      id: 1,
      name: "مبيد حشري واسع الطيف",
      category: "مبيدات حشرية",
      type: "بيرميثرين",
      size: "1 لتر",
      price: "2,500",
      rating: 4.5,
      reviews: 32,
      inStock: true,
      image: "/pesticide-1.jpg",
      brand: "أجري كير",
    },
    {
      id: 2,
      name: "مبيد فطري",
      category: "مبيدات فطرية",
      type: "مانكوزيب",
      size: "500 غ",
      price: "1,800",
      rating: 4.8,
      reviews: 51,
      inStock: true,
      image: "/pesticide-2.jpg",
      brand: "كروب بروتكت",
    },
    {
      id: 3,
      name: "مبيد أعشاب",
      category: "مبيدات أعشاب",
      type: "غليفوسات",
      size: "5 لتر",
      price: "6,500",
      rating: 4.4,
      reviews: 28,
      inStock: false,
      image: "/pesticide-3.jpg",
      brand: "ويد كنترول",
    },
  ]

  const categories = ["جميع الفئات", "أسمدة كيميائية", "أسمدة عضوية", "مبيدات حشرية", "مبيدات فطرية", "مبيدات أعشاب"]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-lime-600 to-green-600 text-white py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-4">
              <Leaf className="h-10 w-10" />
              <h1 className="text-3xl sm:text-4xl font-bold">الأدوية والأسمدة الزراعية</h1>
            </div>
            <p className="text-lg text-lime-50 max-w-2xl text-pretty">
              مستلزمات زراعية عالية الجودة لمحاصيل أفضل وإنتاجية أعلى
            </p>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="bg-white border-b border-border sticky top-16 z-40 shadow-sm">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input placeholder="ابحث عن أسمدة أو مبيدات..." className="pr-10 h-11" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="الفئة" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="التوفر" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="instock">متوفر</SelectItem>
                  <SelectItem value="outofstock">غير متوفر</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-lime-600 hover:bg-lime-700 h-11">
                <Filter className="h-5 w-5 ml-2" />
                تصفية
              </Button>
            </div>
          </div>
        </section>

        {/* Tabs for Fertilizers and Pesticides */}
        <section className="py-8">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex justify-end mb-6">
              <Link href="/supplies/add">
                <Button size="lg" className="bg-lime-600 text-white hover:bg-lime-700">
                  <Plus className="h-5 w-5 ml-2" />
                  أضف منتج زراعي
                </Button>
              </Link>
            </div>

            <Tabs defaultValue="fertilizers" className="w-full">
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
                <TabsTrigger value="fertilizers">الأسمدة</TabsTrigger>
                <TabsTrigger value="pesticides">المبيدات</TabsTrigger>
              </TabsList>

              {/* Fertilizers Tab */}
              <TabsContent value="fertilizers">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-muted-foreground">
                    عرض <span className="font-bold text-foreground">{fertilizers.length}</span> منتج
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {fertilizers.map((product) => (
                    <Card
                      key={product.id}
                      className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                    >
                      <div className="relative">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute top-3 right-3">
                          <Badge className={product.inStock ? "bg-green-600" : "bg-red-600"}>
                            {product.inStock ? "متوفر" : "غير متوفر"}
                          </Badge>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="mb-2">
                          <Badge variant="outline" className="text-xs">
                            {product.category}
                          </Badge>
                        </div>
                        <h3 className="text-lg font-bold text-foreground mb-1 line-clamp-1">{product.name}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{product.brand}</p>

                        <div className="flex items-center gap-1 mb-3">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-bold">{product.rating}</span>
                          <span className="text-sm text-muted-foreground">({product.reviews})</span>
                        </div>

                        <div className="space-y-2 mb-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <Package className="h-4 w-4" />
                            <span>النوع: {product.type}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Package className="h-4 w-4" />
                            <span>الحجم: {product.size}</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-border">
                          <div className="text-2xl font-bold text-lime-600">{product.price} دج</div>
                          <Button size="sm" className="bg-lime-600 hover:bg-lime-700" disabled={!product.inStock}>
                            <ShoppingCart className="h-4 w-4 ml-2" />
                            أضف للسلة
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Pesticides Tab */}
              <TabsContent value="pesticides">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-muted-foreground">
                    عرض <span className="font-bold text-foreground">{pesticides.length}</span> منتج
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {pesticides.map((product) => (
                    <Card
                      key={product.id}
                      className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                    >
                      <div className="relative">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute top-3 right-3">
                          <Badge className={product.inStock ? "bg-green-600" : "bg-red-600"}>
                            {product.inStock ? "متوفر" : "غير متوفر"}
                          </Badge>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="mb-2">
                          <Badge variant="outline" className="text-xs">
                            {product.category}
                          </Badge>
                        </div>
                        <h3 className="text-lg font-bold text-foreground mb-1 line-clamp-1">{product.name}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{product.brand}</p>

                        <div className="flex items-center gap-1 mb-3">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-bold">{product.rating}</span>
                          <span className="text-sm text-muted-foreground">({product.reviews})</span>
                        </div>

                        <div className="space-y-2 mb-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <Package className="h-4 w-4" />
                            <span>النوع: {product.type}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Package className="h-4 w-4" />
                            <span>الحجم: {product.size}</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-border">
                          <div className="text-2xl font-bold text-lime-600">{product.price} دج</div>
                          <Button size="sm" className="bg-lime-600 hover:bg-lime-700" disabled={!product.inStock}>
                            <ShoppingCart className="h-4 w-4 ml-2" />
                            أضف للسلة
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
