"use client"

import type React from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LocationSelector } from "@/components/location-selector"
import { Plus, Upload, X, Eye } from "lucide-react"
import { useState } from "react"

export default function AddSupplyPage() {
  const [images, setImages] = useState<string[]>([])
  const [showPreview, setShowPreview] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    category: "",
    type: "",
    brand: "",
    quantity: "",
    unit: "",
    price: "",
    wilaya: "",
    commune: "",
    description: "",
    composition: "",
    usage: "",
    expiryDate: "",
    certification: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Supply submission:", formData, images)
    alert("تم نشر المنتج بنجاح!")
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const newImages = Array.from(files).map((file) => URL.createObjectURL(file))
      setImages([...images, ...newImages].slice(0, 5))
    }
  }

  const categories = ["أسمدة", "مبيدات حشرية", "مبيدات فطرية", "مبيدات أعشاب", "منشطات نمو", "أخرى"]
  const types = ["عضوي", "كيميائي", "بيولوجي", "مختلط"]
  const units = ["كيلوغرام", "لتر", "طن", "عبوة", "كيس"]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 bg-muted/30 py-8">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">إضافة منتج زراعي</h1>
              <p className="text-muted-foreground">املأ النموذج أدناه لإضافة أسمدة أو أدوية زراعية</p>
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowPreview(!showPreview)}
              className="bg-transparent"
            >
              <Eye className="h-4 w-4 ml-2" />
              {showPreview ? "إخفاء المعاينة" : "معاينة"}
            </Button>
          </div>

          {showPreview && (
            <Card className="p-6 mb-6 bg-blue-50 border-blue-200">
              <h3 className="text-lg font-bold mb-4 text-blue-900">معاينة المنتج</h3>
              <div className="bg-white rounded-lg p-4 border border-border">
                {images.length > 0 && (
                  <img
                    src={images[0] || "/placeholder.svg"}
                    alt="معاينة"
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                )}
                <h4 className="text-xl font-bold text-foreground mb-2">{formData.title || "اسم المنتج"}</h4>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                  <span>{formData.category || "الفئة"}</span>
                  <span>•</span>
                  <span>{formData.type || "النوع"}</span>
                  <span>•</span>
                  <span>{formData.brand || "العلامة"}</span>
                </div>
                <p className="text-2xl font-bold text-[#2d7a3e] mb-2">
                  {formData.price ? `${Number(formData.price).toLocaleString()} دج` : "السعر"}
                  {formData.quantity && formData.unit && (
                    <span className="text-sm text-muted-foreground mr-2">
                      / {formData.quantity} {formData.unit}
                    </span>
                  )}
                </p>
              </div>
            </Card>
          )}

          <form onSubmit={handleSubmit}>
            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-6">معلومات المنتج</h2>

              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">
                    اسم المنتج <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="title"
                    placeholder="مثال: سماد NPK 20-20-20"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="category">
                      الفئة <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                      required
                    >
                      <SelectTrigger id="category">
                        <SelectValue placeholder="اختر الفئة" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="type">
                      النوع <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value) => setFormData({ ...formData, type: value })}
                      required
                    >
                      <SelectTrigger id="type">
                        <SelectValue placeholder="اختر النوع" />
                      </SelectTrigger>
                      <SelectContent>
                        {types.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="brand">
                      العلامة التجارية <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="brand"
                      placeholder="مثال: Yara, Bayer"
                      value={formData.brand}
                      onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="certification">
                      الشهادة <span className="text-muted-foreground text-xs">(اختياري)</span>
                    </Label>
                    <Input
                      id="certification"
                      placeholder="مثال: ISO 9001, عضوي معتمد"
                      value={formData.certification}
                      onChange={(e) => setFormData({ ...formData, certification: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="quantity">
                      الكمية <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="quantity"
                      type="number"
                      placeholder="0"
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="unit">
                      الوحدة <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.unit}
                      onValueChange={(value) => setFormData({ ...formData, unit: value })}
                      required
                    >
                      <SelectTrigger id="unit">
                        <SelectValue placeholder="اختر الوحدة" />
                      </SelectTrigger>
                      <SelectContent>
                        {units.map((unit) => (
                          <SelectItem key={unit} value={unit}>
                            {unit}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">
                      السعر (دج) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="price"
                      type="number"
                      placeholder="0"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="expiryDate">
                      تاريخ الانتهاء <span className="text-muted-foreground text-xs">(اختياري)</span>
                    </Label>
                    <Input
                      id="expiryDate"
                      type="date"
                      value={formData.expiryDate}
                      onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                    />
                  </div>

                  <LocationSelector
                    wilayaValue={formData.wilaya}
                    communeValue={formData.commune}
                    onWilayaChange={(value) => setFormData({ ...formData, wilaya: value })}
                    onCommuneChange={(value) => setFormData({ ...formData, commune: value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="composition">
                    التركيبة <span className="text-muted-foreground text-xs">(اختياري)</span>
                  </Label>
                  <Textarea
                    id="composition"
                    placeholder="مثال: نيتروجين 20%، فوسفور 20%، بوتاسيوم 20%"
                    rows={3}
                    value={formData.composition}
                    onChange={(e) => setFormData({ ...formData, composition: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="usage">
                    طريقة الاستخدام <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="usage"
                    placeholder="اشرح كيفية استخدام المنتج، الجرعات الموصى بها، التوقيت المناسب..."
                    rows={4}
                    value={formData.usage}
                    onChange={(e) => setFormData({ ...formData, usage: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">
                    الوصف <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="اكتب وصفاً تفصيلياً للمنتج، فوائده، المحاصيل المناسبة له..."
                    rows={6}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                  />
                </div>
              </div>
            </Card>

            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-2">
                الصور <span className="text-red-500">*</span>
              </h2>
              <p className="text-sm text-muted-foreground mb-6">
                أضف صوراً واضحة للمنتج والعبوة. الصورة الأولى ستكون الصورة الرئيسية.
              </p>
              <div className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  {images.map((image, index) => (
                    <div
                      key={index}
                      className="relative aspect-square rounded-lg border-2 border-border overflow-hidden"
                    >
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`صورة ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      {index === 0 && (
                        <div className="absolute top-2 right-2 bg-[#2d7a3e] text-white text-xs px-2 py-1 rounded">
                          رئيسية
                        </div>
                      )}
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 left-2 h-8 w-8"
                        onClick={() => setImages(images.filter((_, i) => i !== index))}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  {images.length < 5 && (
                    <label className="aspect-square rounded-lg border-2 border-dashed border-border hover:border-[#2d7a3e] hover:bg-muted/50 transition-colors flex flex-col items-center justify-center gap-2 cursor-pointer">
                      <Upload className="h-8 w-8 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">إضافة صورة</span>
                      <input type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} />
                    </label>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  يمكنك إضافة حتى 5 صور. الحد الأدنى صورة واحدة. ({images.length}/5)
                </p>
              </div>
            </Card>

            <div className="flex gap-4">
              <Button
                type="submit"
                className="flex-1 bg-[#2d7a3e] hover:bg-[#1f5a2d] h-11"
                disabled={images.length === 0}
              >
                <Plus className="h-5 w-5 ml-2" />
                نشر المنتج
              </Button>
              <Button type="button" variant="outline" className="h-11 bg-transparent">
                إلغاء
              </Button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  )
}
