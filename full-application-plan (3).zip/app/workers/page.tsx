import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, MapPin, Star, Users, Briefcase, Phone, Mail, Plus } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"

export default function WorkersPage() {
  const workers = [
    {
      id: 1,
      name: "أحمد بن محمد",
      specialty: "خبير زراعة الحبوب",
      experience: "15 سنة",
      location: "الجزائر العاصمة",
      rating: 4.8,
      reviews: 24,
      hourlyRate: "1,500",
      availability: "متاح",
      skills: ["حصاد", "زراعة", "صيانة معدات"],
      image: "/worker-1.jpg",
    },
    {
      id: 2,
      name: "فاطمة الزهراء",
      specialty: "متخصصة في البيوت البلاستيكية",
      experience: "8 سنوات",
      location: "وهران",
      rating: 4.9,
      reviews: 31,
      hourlyRate: "1,800",
      availability: "متاح",
      skills: ["بيوت بلاستيكية", "زراعة عضوية", "إدارة"],
      image: "/worker-2.jpg",
    },
    {
      id: 3,
      name: "يوسف العربي",
      specialty: "فني صيانة معدات زراعية",
      experience: "12 سنة",
      location: "قسنطينة",
      rating: 4.7,
      reviews: 19,
      hourlyRate: "2,000",
      availability: "مشغول",
      skills: ["صيانة", "إصلاح", "كهرباء"],
      image: "/worker-3.jpg",
    },
    {
      id: 4,
      name: "سعيد بلعيد",
      specialty: "خبير أنظمة الري",
      experience: "10 سنوات",
      location: "سطيف",
      rating: 4.6,
      reviews: 15,
      hourlyRate: "1,700",
      availability: "متاح",
      skills: ["ري بالتنقيط", "تركيب", "صيانة"],
      image: "/worker-4.jpg",
    },
    {
      id: 5,
      name: "خديجة مرزوق",
      specialty: "مهندسة زراعية",
      experience: "6 سنوات",
      location: "بجاية",
      rating: 5.0,
      reviews: 28,
      hourlyRate: "2,500",
      availability: "متاح",
      skills: ["استشارات", "تخطيط", "إدارة مشاريع"],
      image: "/worker-5.jpg",
    },
    {
      id: 6,
      name: "كريم الدين",
      specialty: "عامل زراعي عام",
      experience: "5 سنوات",
      location: "تلمسان",
      rating: 4.5,
      reviews: 12,
      hourlyRate: "1,200",
      availability: "متاح",
      skills: ["حصاد", "زراعة", "تنظيف"],
      image: "/worker-6.jpg",
    },
  ]

  const specialties = [
    "جميع التخصصات",
    "خبير زراعة",
    "فني صيانة",
    "مهندس زراعي",
    "عامل عام",
    "متخصص بيوت بلاستيكية",
    "خبير أنظمة ري",
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-blue-600 to-cyan-600 text-white py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-4">
              <Users className="h-10 w-10" />
              <h1 className="text-3xl sm:text-4xl font-bold">العمال الزراعيون</h1>
            </div>
            <p className="text-lg text-blue-50 max-w-2xl text-pretty">
              ابحث عن عمال مؤهلين أو قدم خدماتك كعامل زراعي محترف
            </p>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="bg-white border-b border-border sticky top-16 z-40 shadow-sm">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input placeholder="ابحث عن عمال..." className="pr-10 h-11" />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="التخصص" />
                </SelectTrigger>
                <SelectContent>
                  {specialties.map((specialty) => (
                    <SelectItem key={specialty} value={specialty}>
                      {specialty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-11">
                  <SelectValue placeholder="التوفر" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="available">متاح</SelectItem>
                  <SelectItem value="busy">مشغول</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-blue-600 hover:bg-blue-700 h-11">
                <Filter className="h-5 w-5 ml-2" />
                تصفية
              </Button>
            </div>
          </div>
        </section>

        {/* Workers Grid */}
        <section className="py-8">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center mb-6">
              <p className="text-muted-foreground">
                عرض <span className="font-bold text-foreground">{workers.length}</span> عامل
              </p>
              <Link href="/workers/add">
                <Button size="lg" className="bg-blue-600 text-white hover:bg-blue-700">
                  <Plus className="h-5 w-5 ml-2" />
                  سجل كعامل
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {workers.map((worker) => (
                <Card
                  key={worker.id}
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={worker.image || "/placeholder.svg"} alt={worker.name} />
                        <AvatarFallback>{worker.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-foreground mb-1">{worker.name}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{worker.specialty}</p>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-bold">{worker.rating}</span>
                          <span className="text-sm text-muted-foreground">({worker.reviews} تقييم)</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Briefcase className="h-4 w-4" />
                        <span>خبرة {worker.experience}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        <span>{worker.location}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {worker.skills.map((skill, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <div>
                        <div className="text-2xl font-bold text-blue-600">{worker.hourlyRate} دج</div>
                        <span className="text-xs text-muted-foreground">في الساعة</span>
                      </div>
                      <Badge
                        className={
                          worker.availability === "متاح"
                            ? "bg-green-100 text-green-700 border-green-200"
                            : "bg-gray-100 text-gray-700 border-gray-200"
                        }
                      >
                        {worker.availability}
                      </Badge>
                    </div>

                    <div className="flex gap-2 mt-4">
                      <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                        <Phone className="h-4 w-4 ml-2" />
                        اتصل
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                        <Mail className="h-4 w-4 ml-2" />
                        راسل
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center gap-2 mt-8">
              <Button variant="outline" disabled>
                السابق
              </Button>
              <Button variant="outline" className="bg-blue-600 text-white hover:bg-blue-700 hover:text-white">
                1
              </Button>
              <Button variant="outline">2</Button>
              <Button variant="outline">3</Button>
              <Button variant="outline">التالي</Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
