"use client"

import type React from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { LocationSelector } from "@/components/location-selector"
import { Plus, Upload, Eye, Camera } from "lucide-react"
import { useState } from "react"

export default function AddWorkerPage() {
  const [profileImage, setProfileImage] = useState<string>("")
  const [showPreview, setShowPreview] = useState(false)
  const [formData, setFormData] = useState({
    fullName: "",
    age: "",
    phone: "",
    wilaya: "",
    commune: "",
    specialization: "",
    experience: "",
    dailyRate: "",
    availability: "",
    description: "",
    skills: [] as string[],
    languages: [] as string[],
    hasTransport: false,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Worker profile submission:", formData, profileImage)
    alert("تم إنشاء الملف الشخصي بنجاح!")
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setProfileImage(URL.createObjectURL(file))
    }
  }

  const specializations = [
    "زراعة الحبوب",
    "زراعة الخضروات",
    "زراعة الفواكه",
    "تربية المواشي",
    "البيوت البلاستيكية",
    "أنظمة الري",
    "قيادة الجرارات",
    "الحصاد",
    "التقليم",
    "أخرى",
  ]

  const availableSkills = [
    "قيادة الجرارات",
    "الحصاد",
    "التقليم",
    "الري",
    "التسميد",
    "مكافحة الآفات",
    "صيانة المعدات",
    "البيوت البلاستيكية",
  ]

  const languages = ["العربية", "الفرنسية", "الأمازيغية", "الإنجليزية"]

  const toggleSkill = (skill: string) => {
    setFormData({
      ...formData,
      skills: formData.skills.includes(skill)
        ? formData.skills.filter((s) => s !== skill)
        : [...formData.skills, skill],
    })
  }

  const toggleLanguage = (language: string) => {
    setFormData({
      ...formData,
      languages: formData.languages.includes(language)
        ? formData.languages.filter((l) => l !== language)
        : [...formData.languages, language],
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 bg-muted/30 py-8">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">إنشاء ملف عامل زراعي</h1>
              <p className="text-muted-foreground">املأ النموذج أدناه لإنشاء ملفك الشخصي كعامل زراعي</p>
            </div>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowPreview(!showPreview)}
              className="bg-transparent"
            >
              <Eye className="h-4 w-4 ml-2" />
              {showPreview ? "إخفاء المعاينة" : "معاينة"}
            </Button>
          </div>

          {showPreview && (
            <Card className="p-6 mb-6 bg-blue-50 border-blue-200">
              <h3 className="text-lg font-bold mb-4 text-blue-900">معاينة الملف الشخصي</h3>
              <div className="bg-white rounded-lg p-6 border border-border">
                <div className="flex items-start gap-4">
                  <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                    {profileImage ? (
                      <img
                        src={profileImage || "/placeholder.svg"}
                        alt="صورة شخصية"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Camera className="h-8 w-8 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-xl font-bold text-foreground mb-1">{formData.fullName || "الاسم الكامل"}</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      {formData.specialization || "التخصص"} • {formData.experience || "0"} سنوات خبرة
                    </p>
                    <p className="text-lg font-bold text-[#2d7a3e]">
                      {formData.dailyRate ? `${Number(formData.dailyRate).toLocaleString()} دج/يوم` : "الأجر اليومي"}
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          )}

          <form onSubmit={handleSubmit}>
            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-6">المعلومات الشخصية</h2>

              <div className="space-y-6">
                <div className="flex justify-center mb-6">
                  <div className="relative">
                    <div className="w-32 h-32 rounded-full bg-muted flex items-center justify-center border-4 border-border overflow-hidden">
                      {profileImage ? (
                        <img
                          src={profileImage || "/placeholder.svg"}
                          alt="صورة شخصية"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Upload className="h-12 w-12 text-muted-foreground" />
                      )}
                    </div>
                    <label className="absolute bottom-0 left-0 rounded-full bg-[#2d7a3e] hover:bg-[#1f5a2d] text-white px-4 py-2 text-sm cursor-pointer">
                      رفع صورة
                      <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                    </label>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">
                      الاسم الكامل <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="fullName"
                      placeholder="أدخل اسمك الكامل"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="age">
                      العمر <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="0"
                      min="18"
                      max="70"
                      value={formData.age}
                      onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">
                      رقم الهاتف <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="0555 12 34 56"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      required
                    />
                  </div>

                  <LocationSelector
                    wilayaValue={formData.wilaya}
                    communeValue={formData.commune}
                    onWilayaChange={(value) => setFormData({ ...formData, wilaya: value })}
                    onCommuneChange={(value) => setFormData({ ...formData, commune: value })}
                    required
                  />
                </div>
              </div>
            </Card>

            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-6">الخبرة والمهارات</h2>

              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="specialization">
                      التخصص <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.specialization}
                      onValueChange={(value) => setFormData({ ...formData, specialization: value })}
                      required
                    >
                      <SelectTrigger id="specialization">
                        <SelectValue placeholder="اختر التخصص" />
                      </SelectTrigger>
                      <SelectContent>
                        {specializations.map((spec) => (
                          <SelectItem key={spec} value={spec}>
                            {spec}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="experience">
                      سنوات الخبرة <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="experience"
                      type="number"
                      placeholder="0"
                      min="0"
                      max="50"
                      value={formData.experience}
                      onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dailyRate">
                      الأجر اليومي (دج) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="dailyRate"
                      type="number"
                      placeholder="0"
                      value={formData.dailyRate}
                      onChange={(e) => setFormData({ ...formData, dailyRate: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="availability">
                      التوفر <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.availability}
                      onValueChange={(value) => setFormData({ ...formData, availability: value })}
                      required
                    >
                      <SelectTrigger id="availability">
                        <SelectValue placeholder="اختر التوفر" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full-time">دوام كامل</SelectItem>
                        <SelectItem value="part-time">دوام جزئي</SelectItem>
                        <SelectItem value="seasonal">موسمي</SelectItem>
                        <SelectItem value="on-demand">حسب الطلب</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>
                    المهارات <span className="text-red-500">*</span>
                  </Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {availableSkills.map((skill) => (
                      <div key={skill} className="flex items-center gap-2">
                        <Checkbox
                          id={skill}
                          checked={formData.skills.includes(skill)}
                          onCheckedChange={() => toggleSkill(skill)}
                        />
                        <Label htmlFor={skill} className="text-sm cursor-pointer">
                          {skill}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>
                    اللغات <span className="text-muted-foreground text-xs">(اختياري)</span>
                  </Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {languages.map((language) => (
                      <div key={language} className="flex items-center gap-2">
                        <Checkbox
                          id={language}
                          checked={formData.languages.includes(language)}
                          onCheckedChange={() => toggleLanguage(language)}
                        />
                        <Label htmlFor={language} className="text-sm cursor-pointer">
                          {language}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox
                    id="hasTransport"
                    checked={formData.hasTransport}
                    onCheckedChange={(checked) => setFormData({ ...formData, hasTransport: checked as boolean })}
                  />
                  <Label htmlFor="hasTransport" className="cursor-pointer">
                    لدي وسيلة نقل خاصة
                  </Label>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">
                    نبذة عنك <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="اكتب نبذة عن خبرتك ومهاراتك في المجال الزراعي، إنجازاتك، ما يميزك عن الآخرين..."
                    rows={6}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                  />
                </div>
              </div>
            </Card>

            <div className="flex gap-4">
              <Button type="submit" className="flex-1 bg-[#2d7a3e] hover:bg-[#1f5a2d] h-11">
                <Plus className="h-5 w-5 ml-2" />
                إنشاء الملف الشخصي
              </Button>
              <Button type="button" variant="outline" className="h-11 bg-transparent">
                إلغاء
              </Button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  )
}
