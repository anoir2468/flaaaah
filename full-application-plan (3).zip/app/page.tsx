import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"
import { AppTour } from "@/components/app-tour"
import {
  Tractor,
  Users,
  GraduationCap,
  MapPin,
  Building2,
  Leaf,
  ArrowLeft,
  Search,
  PlusCircle,
  Star,
} from "lucide-react"

export default function HomePage() {
  const features = [
    {
      icon: Tractor,
      title: "سوق العتاد الزراعي",
      description: "جرارات، محاريث، وآلات حصاد للبيع أو الكراء في ولايتك.",
      href: "/equipment",
      stats: "500+ إعلان نشط",
    },
    {
      icon: Users,
      title: "سوق اليد العاملة",
      description: "ابحث عن عمال متخصصين أو تقنيين فلاحيين لموسم الحصاد.",
      href: "/workers",
      stats: "1200+ عامل مسجل",
    },
    {
      icon: MapPin,
      title: "الأراضي والعقارات",
      description: "أراضي فلاحية للكراء أو التنازل مع تفاصيل التربة والري.",
      href: "/land",
      stats: "300+ قطعة أرض",
    },
    {
      icon: Leaf,
      title: "الأسمدة والأدوية",
      description: "منتجات وقاية النباتات وأسمدة عضوية وكيميائية معتمدة.",
      href: "/supplies",
      stats: "توصيل لجميع الولايات",
    },
    {
      icon: Building2,
      title: "البيوت البلاستيكية",
      description: "منشآت زراعية حديثة وتجهيزات الغرف المبردة.",
      href: "/facilities",
      stats: "أحدث التقنيات",
    },
    {
      icon: GraduationCap,
      title: "مركز التكوين",
      description: "دروس تعليمية ونصائح تقنية لرفع مردودية محاصيلك.",
      href: "/training",
      stats: "بإشراف خبراء",
    },
  ]

  const benefits = ["منصة آمنة وموثوقة", "أسعار تنافسية", "دعم فني متواصل", "تغطية جميع الولايات"]

  return (
    <div className="min-h-screen flex flex-col bg-[#fafaf9]">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative h-[600px] flex items-center overflow-hidden">
          <Image src="/idyllic-farm.jpg" alt="Farm landscape" fill className="object-cover brightness-[0.4]" priority />
          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full z-10">
            <div className="max-w-3xl text-white">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-sm font-medium mb-6">
                <Star className="h-4 w-4 text-accent fill-accent" />
                <span>المنصة رقم #1 للفلاح الجزائري</span>
              </div>
              <h1 className="text-5xl md:text-7xl font-bold leading-[1.1] mb-6 drop-shadow-lg">
                فلاحتنا، <span className="text-secondary">مستقبلنا</span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-200 mb-10 max-w-2xl leading-relaxed">
                اكتشف أول منصة متكاملة لربط الفلاحين بالخدمات والعتاد في كل ربوع الوطن.
              </p>

              {/* Quick Search Bar */}
              <div className="bg-white p-2 rounded-2xl shadow-2xl flex flex-col md:flex-row gap-2 max-w-2xl">
                <div className="flex-1 flex items-center px-4 gap-3 border-l md:border-l border-gray-100">
                  <Search className="h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="ماذا تبحث اليوم؟ (جرار، بذور، عمال...)"
                    className="w-full py-3 outline-none text-gray-800 placeholder:text-gray-400"
                  />
                </div>
                <Button size="lg" className="bg-primary hover:bg-primary-dark text-white px-8 rounded-xl h-14">
                  بحث سريع
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 relative overflow-hidden">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-end mb-16">
              <div className="max-w-2xl">
                <h2 className="text-4xl font-bold text-primary mb-4">اكتشف الخدمات</h2>
                <p className="text-lg text-muted-foreground">
                  تصفح الأقسام المتخصصة والمصممة لتلبية احتياجات مشروعك الفلاحي.
                </p>
              </div>
              <Button variant="ghost" className="text-primary font-bold gap-2">
                عرض كل الأقسام <ArrowLeft className="h-4 w-4" />
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <Link key={index} href={feature.href} className="group">
                  <Card className="relative p-8 h-full bg-white border-none shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_20px_40px_rgb(0,0,0,0.08)] transition-all duration-500 rounded-3xl overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16 transition-transform duration-500 group-hover:scale-150" />
                    <div className="relative z-10">
                      <div className="w-16 h-16 rounded-2xl bg-[#f0fdf4] flex items-center justify-center mb-6 transition-colors group-hover:bg-primary">
                        <feature.icon className="h-8 w-8 text-primary group-hover:text-white transition-colors" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                      <p className="text-gray-600 leading-relaxed mb-6">{feature.description}</p>
                      <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
                        <span className="text-sm font-semibold text-primary">{feature.stats}</span>
                        <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center group-hover:bg-secondary group-hover:text-white transition-colors">
                          <ArrowLeft className="h-4 w-4" />
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="pb-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="bg-primary rounded-[3rem] overflow-hidden shadow-2xl relative">
              <div className="grid md:grid-cols-2 items-center">
                <div className="p-12 md:p-20 text-white z-10">
                  <span className="inline-block px-4 py-1 rounded-full bg-white/20 text-sm font-bold mb-6 italic">
                    عرض خاص
                  </span>
                  <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">سهّل عملك مع أحدث الجرارات</h2>
                  <p className="text-xl text-green-50 mb-10 leading-relaxed">
                    اكتشف تشكيلة واسعة من الجرارات الحديثة المتوفرة للكراء أو البيع بأسعار تنافسية في ولاية سطيف وعين
                    الدفلى.
                  </p>
                  <Button
                    size="lg"
                    className="bg-secondary hover:bg-earth text-white px-10 h-14 rounded-2xl font-bold text-lg"
                  >
                    تصفح الجرارات الآن
                  </Button>
                </div>
                <div className="relative h-[400px] md:h-full min-h-[500px]">
                  <Image src="/classic-red-tractor.jpg" alt="New tractor" fill className="object-cover" />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-white">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-4xl font-bold text-primary mb-16">كيف تستخدم المنصة؟</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 rounded-full bg-sky flex items-center justify-center text-3xl font-bold text-primary mb-6 shadow-sm">
                  1
                </div>
                <h3 className="text-2xl font-bold mb-4">أنشئ حسابك</h3>
                <p className="text-gray-600">سجل مجاناً كفلاح أو تاجر أو عامل زراعي.</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 rounded-full bg-sky flex items-center justify-center text-3xl font-bold text-primary mb-6 shadow-sm">
                  2
                </div>
                <h3 className="text-2xl font-bold mb-4">أضف إعلانك</h3>
                <p className="text-gray-600">صور منتجك أو خدمتك، حدد السعر والموقع وانشر فوراً.</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 rounded-full bg-sky flex items-center justify-center text-3xl font-bold text-primary mb-6 shadow-sm">
                  3
                </div>
                <h3 className="text-2xl font-bold mb-4">تواصل وبع</h3>
                <p className="text-gray-600">استقبل المكالمات والرسائل من المهتمين مباشرة.</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA with Mobile App Focus */}
        <section className="py-24 relative overflow-hidden">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="bg-secondary/10 rounded-[3rem] p-12 md:p-20 flex flex-col md:flex-row items-center gap-12 border border-secondary/20">
              <div className="flex-1">
                <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">احمل منصتك في جيبك</h2>
                <p className="text-xl text-gray-700 mb-10 leading-relaxed">
                  قريباً.. تطبيق الموبايل الأصلي لمتابعة إعلاناتك والتواصل مع الفلاحين في أي مكان وفي أي وقت.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button size="lg" className="bg-primary hover:bg-primary-dark h-14 px-8 rounded-2xl gap-3">
                    <PlusCircle className="h-5 w-5" />
                    اضف إعلانك الأول
                  </Button>
                </div>
              </div>
              <div className="relative w-full max-w-md aspect-square rounded-[2rem] overflow-hidden shadow-2xl">
                <Image src="/diverse-farmers-harvest.jpg" alt="Farmers using the app" fill className="object-cover" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      {/* أضفت زر الجولة التفاعلية للتطبيق */}
      <AppTour />
    </div>
  )
}
