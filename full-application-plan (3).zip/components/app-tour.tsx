"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronRight, ChevronLeft, Play, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

const steps = [
  {
    title: "مرحباً بك في منصة الفلاح",
    description:
      "أول منصة جزائرية متكاملة لخدمة الفلاح. سنأخذك في جولة سريعة لمعرفة كيفية عمل التطبيق والخدمات التي نقدمها لك.",
    image: "/algerian-agriculture-landscape.jpg",
  },
  {
    title: "سوق العتاد والمعدات",
    description:
      "هنا يمكنك البحث عن الجرارات، الحاصدات، والبيوت البلاستيكية للبيع أو الكراء مع إمكانية التصفية حسب الولاية والبلدية لضمان القرب منك.",
    image: "/tractor-in-farm.jpg",
  },
  {
    title: "إدارة العمال والتوظيف",
    description:
      "تطبيقنا يسهل عليك إيجاد عمال مؤهلين لموسم الحصاد، أو يمكنك التسجيل كعامل فلاحي لعرض خبراتك وتلقي طلبات التوظيف مباشرة.",
    image: "/farmer-working-field.jpg",
  },
  {
    title: "الأراضي والمستلزمات",
    description:
      "تصفح الأراضي الفلاحية المتاحة للكراء أو البيع، واطلب الأسمدة والأدوية الزراعية من موردين موثوقين مع خدمة التوصيل.",
    image: "/agricultural-supplies.jpg",
  },
  {
    title: "نشر إعلانك باحترافية",
    description:
      "بخطوات بسيطة: اختر القسم المناسب، ارفع صوراً واضحة، حدد السعر والموقع، وانشر إعلانك ليصل إلى آلاف الفلاحين والمهتمين في الجزائر.",
    image: "/mobile-app-listing.jpg",
  },
]

export function AppTour() {
  const [isOpen, setIsOpen] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      setIsOpen(false)
    }
  }

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    }
  }

  return (
    <>
      <Button
        onClick={() => {
          setIsOpen(true)
          setCurrentStep(0)
        }}
        className="fixed bottom-6 right-6 gap-2 bg-green-600 hover:bg-green-700 shadow-2xl rounded-full px-6 py-8 z-50 text-white font-bold transition-all hover:scale-105 active:scale-95"
      >
        <Play className="w-5 h-5 fill-current" />
        جولة في التطبيق
      </Button>

      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="max-w-md w-full"
            >
              <Card className="overflow-hidden border-none shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)] bg-white rounded-[2.5rem]">
                <div className="relative h-56 bg-muted">
                  <img
                    src={steps[currentStep].image || "/placeholder.svg"}
                    alt={steps[currentStep].title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-4 right-4 text-white bg-black/20 hover:bg-black/40 rounded-full"
                    onClick={() => setIsOpen(false)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                  <div className="absolute bottom-4 right-6 left-6">
                    <h3 className="text-2xl font-bold text-white mb-1 leading-tight drop-shadow-md">
                      {steps[currentStep].title}
                    </h3>
                  </div>
                </div>

                <div className="p-8 text-right" dir="rtl">
                  <p className="text-gray-600 leading-relaxed mb-8 text-lg min-h-[80px]">
                    {steps[currentStep].description}
                  </p>

                  <div className="flex items-center justify-between">
                    <div className="flex gap-1.5">
                      {steps.map((_, i) => (
                        <div
                          key={i}
                          className={`h-1.5 rounded-full transition-all duration-300 ${
                            i === currentStep ? "w-8 bg-green-600" : "w-2 bg-gray-200"
                          }`}
                        />
                      ))}
                    </div>

                    <div className="flex gap-3">
                      {currentStep > 0 && (
                        <Button
                          variant="ghost"
                          onClick={handlePrev}
                          className="text-gray-500 hover:text-green-700 hover:bg-green-50 rounded-xl"
                        >
                          <ChevronRight className="w-4 h-4 ml-1" /> السابق
                        </Button>
                      )}
                      <Button
                        className="bg-green-600 hover:bg-green-700 text-white px-6 rounded-xl font-bold shadow-lg shadow-green-200"
                        onClick={handleNext}
                      >
                        {currentStep === steps.length - 1 ? "فهمت، لنبدأ!" : "التالي"}
                        {currentStep < steps.length - 1 && <ChevronLeft className="w-4 h-4 mr-1" />}
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  )
}
